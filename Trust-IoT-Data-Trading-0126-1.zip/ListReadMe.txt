1、修改文件目录下properties配置文件
arbitratorAddress 、dataOwnerAddress、dataBuyerAddress钱包地址，contractAddress合约地址
2、修改测试链，原测试链失效，使用infura配置sepolia测试链
3、修改wallet目录下钱包配置json文件，包含地址以及密码等信息
4、修改target/classes/com/nonRepudiation/ContractCall.class中52行引用测试文件地址
5、修改target/classes/com/nonRepudiationOfXu/ContractCallOfXu.class中50行引用测试文件地址
6、使用Ganache搭建本地测试链接进行测试
7、使用线上版Remix进行智能合约测试